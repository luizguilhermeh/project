package financeiro.web;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import financeiro.usuario.Usuario;
import financeiro.usuario.UsuarioRN;

@ManagedBean(name="usuarioBean")
@RequestScoped
public class UsuarioBean {

	private Usuario usuario = new Usuario();
	private String confirmaSenha;
	private  List<Usuario> lista;
	private String destinoSalvar;
	
	public String novo(){
		this.usuario = new Usuario();
		this.usuario.setAtivo(true);
		return "usuario";
	}
	
	public String editar(){
		this.confirmaSenha = this.usuario.getSenha();
		return "/publico/usuario";
	}
	
	public String salvar(){
		FacesContext facesContext = FacesContext.getCurrentInstance();
		
		String senha = this.usuario.getSenha();
		if(!senha.equals(this.confirmaSenha)){
			FacesMessage faceMessage = new FacesMessage("A senhas não conferem");
			facesContext.addMessage(null, faceMessage);
			return null;
		}
		
		UsuarioRN usuarioRN = new UsuarioRN();
		usuarioRN.salvar(this.usuario);
		
		return "usuarioSucesso";
	} 
	
	public String excluir() {
		UsuarioRN rn = new UsuarioRN();
		rn.excluir(this.usuario);
		this.lista = null;
		return null;
	}	
	
	public String ativar() {
		if(this.usuario.isAtivo()){
			this.usuario.setAtivo(false);
		}else{
			this.usuario.setAtivo(true);
		}
		UsuarioRN rn = new UsuarioRN();
		rn.salvar(this.usuario);
		return null;
	}
	
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public String getConfirmaSenha() {
		return confirmaSenha;
	}
	public void setConfirmaSenha(String confrimaSenha) {
		this.confirmaSenha = confrimaSenha;
	}

	public String getDestinoSalvar() {
		return destinoSalvar;
	}

	public void setDestinoSalvar(String destinoSalvar) {
		this.destinoSalvar = destinoSalvar;
	}

	public List<Usuario> getLista() {
		if(this.lista == null){
			UsuarioRN rn = new UsuarioRN();
			this.lista = rn.listar();
		}
		return lista;
	}
	
	
}
